import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import heroImage1 from "@/assets/hero-1.jpg";
import heroImage2 from "@/assets/hero-2.jpg";
import heroImage3 from "@/assets/hero-3.jpg";

interface Slide {
  image: string;
  title: string;
  subtitle: string;
  description: string;
}

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState<Slide[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Default fallback slides
  const defaultSlides: Slide[] = [
    {
      image: heroImage1,
      title: "Advancing Academic Excellence",
      subtitle: "Featured Research",
      description: "Discover groundbreaking research and innovative methodologies that shape the future of education and professional development."
    },
    {
      image: heroImage2,
      title: "Learning Without Boundaries",
      subtitle: "Educational Innovation",
      description: "Explore modern learning environments and collaborative spaces that foster intellectual growth and academic achievement."
    },
    {
      image: heroImage3,
      title: "Research & Innovation",
      subtitle: "Scientific Discovery",
      description: "Access cutting-edge research facilities and scientific breakthroughs that drive progress in various academic disciplines."
    }
  ];

  const fetchSlides = async () => {
    try {
      const { data, error } = await supabase
        .from('hero_slides')
        .select('*')
        .eq('is_active', true)
        .order('order_index', { ascending: true });

      if (error) {
        console.error('Error fetching hero slides:', error);
        setSlides(defaultSlides);
        return;
      }

      if (data && data.length > 0) {
        const formattedSlides: Slide[] = data.map(slide => ({
          image: slide.image_url,
          title: slide.title,
          subtitle: slide.subtitle,
          description: slide.description
        }));
        setSlides(formattedSlides);
      } else {
        setSlides(defaultSlides);
      }
    } catch (error) {
      console.error('Error fetching hero slides:', error);
      setSlides(defaultSlides);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSlides();
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  // Auto-slide functionality
  useEffect(() => {
    if (slides.length > 1) {
      const interval = setInterval(nextSlide, 6000);
      return () => clearInterval(interval);
    }
  }, [slides.length]);

  if (isLoading) {
    return (
      <section className="relative h-[70vh] min-h-[500px] overflow-hidden bg-muted animate-pulse">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="h-8 bg-muted-foreground/20 rounded w-64 mb-4"></div>
            <div className="h-4 bg-muted-foreground/20 rounded w-48"></div>
          </div>
        </div>
      </section>
    );
  }

  if (slides.length === 0) {
    return (
      <section className="relative h-[70vh] min-h-[500px] overflow-hidden bg-muted">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <h1 className="text-4xl font-bold mb-4">Welcome to IPLR</h1>
            <p className="text-lg">No slides available</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative h-[70vh] min-h-[500px] overflow-hidden">
      {/* Slides */}
      <div className="relative h-full">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? "opacity-100" : "opacity-0"
            }`}
          >
            <div
              className="absolute inset-0 bg-cover bg-center bg-no-repeat"
              style={{ backgroundImage: `url(${slide.image})` }}
            />
            <div className="absolute inset-0 bg-black/30" />
            
        {/* Hero Content - More refined overlay */}
        <div className="relative h-full flex items-center justify-center text-center px-6">
          <div className="max-w-5xl mx-auto text-white">
            <p className="text-xs font-body text-white/90 mb-4 uppercase tracking-[0.3em] border-b border-white/20 pb-2 inline-block">
              {slide.subtitle}
            </p>
            <h1 className="text-4xl md:text-7xl font-academic font-bold mb-8 leading-[0.9] tracking-tight">
              {slide.title}
            </h1>
            <p className="text-base md:text-lg font-body font-light leading-relaxed max-w-3xl mx-auto opacity-90">
              {slide.description}
            </p>
          </div>
        </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <Button
        variant="ghost"
        size="sm"
        onClick={prevSlide}
        className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 border border-white/20 text-white p-3 rounded-full backdrop-blur-sm transition-all duration-300"
      >
        <ChevronLeft className="h-5 w-5" />
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        onClick={nextSlide}
        className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 border border-white/20 text-white p-3 rounded-full backdrop-blur-sm transition-all duration-300"
      >
        <ChevronRight className="h-5 w-5" />
      </Button>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide 
                ? "bg-white scale-110" 
                : "bg-white/50 hover:bg-white/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroCarousel;